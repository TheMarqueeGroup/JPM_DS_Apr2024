# -*- coding: utf-8 -*-
"""
Created on Thu Jun 16 00:30:30 2022

@author: Bogdan Tudose
"""

import numpy as np
import scipy.stats as si
import math 
    
#%%    
def N(x):
    return si.norm.cdf(x)
    
def callOption(S, K, T, r, q, sigma):
    d1 = (np.log(S/K) + (r - q + sigma**2/2)*T) / (sigma*np.sqrt(T))
    d2 = d1 - sigma* np.sqrt(T)
    return S*np.exp(-q*T) * N(d1) - K * np.exp(-r*T)* N(d2)

def putOption(S, K, T, r, q, sigma):
    d1 = (np.log(S/K) + (r - q + sigma**2/2)*T) / (sigma*np.sqrt(T))
    d2 = d1 - sigma* np.sqrt(T)
    return K*np.exp(-r*T)*N(-d2) - S*np.exp(-q*T)*N(-d1)
    
#%%
callOption(100,100,30/365,0.05,0.01,0.25)
putOption(100,100,30/365,0.05,0.01,0.25)

